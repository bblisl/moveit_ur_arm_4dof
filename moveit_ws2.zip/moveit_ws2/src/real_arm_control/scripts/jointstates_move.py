#!/usr/bin/env python3
import numpy as np
import rospy
import math
from sensor_msgs.msg import JointState
from ServoControl import setBusServoMove

class JointStateToServoNode:
    def __init__(self):
        rospy.init_node('joint_state_to_servo_node')

        # 关节-舵机映射及转换参数
        self.joint_servo_map = {
            'joint1': 4,
            'joint2': 3,
            'joint3': 2,
            'joint4_left': 1
        }

        self.joint_conversion = {
            'joint1': {'offset': 120.0, 'ratio': 1.0},
            'joint2': {'offset': 217.2, 'ratio': -1.0},
            'joint3': {'offset': 120.0, 'ratio': -1.0},
            'joint4_left': {
                'range': {
                    'rad': [0.0, 0.024],
                    'deg': [160.0, 67.0]
                }
            }
        }

        # 存储当前关节位置和插值状态
        self.current_positions = {name: None for name in self.joint_servo_map.keys()}
        self.interpolation_states = {
            name: {
                'start_angle': None,
                'target_angle': None,
                'start_time': None
            } for name in self.joint_servo_map.keys()
        }

        # 运动参数
        self.move_duration = 55  # 单位ms
        self.interpolation_time = 0.1  # 插值时间（秒）

        # 订阅/joint_states
        self.sub = rospy.Subscriber('/joint_states', JointState, self.joint_state_callback)

        # 创建50Hz定时器
        self.timer = rospy.Timer(rospy.Duration(0.02), self.timer_callback)  # 50Hz

    def calculate_servo_angle(self, joint_name, rad_value):
        """计算舵机对应角度（单位：度）"""
        if joint_name == 'joint4_left':
            rad_range = self.joint_conversion[joint_name]['range']['rad']
            deg_range = self.joint_conversion[joint_name]['range']['deg']
            clamped_rad = max(rad_range[0], min(rad_range[1], rad_value))
            return np.interp(clamped_rad, rad_range, deg_range)
        else:
            conv = self.joint_conversion[joint_name]
            return conv['offset'] + conv['ratio'] * math.degrees(rad_value)

    def joint_state_callback(self, msg):
        """存储最新关节状态并更新插值目标"""
        name_to_index = {name: idx for idx, name in enumerate(msg.name)}
        for joint_name in self.joint_servo_map.keys():
            if joint_name in name_to_index:
                rad_value = msg.position[name_to_index[joint_name]]
                self.current_positions[joint_name] = rad_value
                
                # 计算新目标角度
                new_target = self.calculate_servo_angle(joint_name, rad_value)
                
                # 获取当前插值状态
                state = self.interpolation_states[joint_name]
                
                # 当目标发生变化时更新插值参数
                if state['target_angle'] != new_target:
                    state['start_angle'] = state['target_angle'] or new_target
                    state['target_angle'] = new_target
                    state['start_time'] = rospy.Time.now()

    def timer_callback(self, event):
        """定时器回调函数，执行线性插值计算"""
        current_time = rospy.Time.now()
        
        for joint_name, servo_id in self.joint_servo_map.items():
            if self.current_positions[joint_name] is None:
                continue

            try:
                state = self.interpolation_states[joint_name]
                
                # 初始化检查
                if state['start_angle'] is None or state['target_angle'] is None:
                    state['start_angle'] = state['target_angle']
                    state['start_time'] = current_time
                    continue

                # 计算插值进度
                elapsed = (current_time - state['start_time']).to_sec()
                if elapsed >= self.interpolation_time:
                    current_angle = state['target_angle']
                else:
                    # 线性插值计算
                    progress = elapsed / self.interpolation_time
                    current_angle = state['start_angle'] + (
                        state['target_angle'] - state['start_angle']) * progress

                # 计算脉冲宽度（0-1000对应0-240度）
                pulse = int(current_angle * 1000 / 240)
                pulse = max(0, min(1000, pulse))  # 硬件限制

                # 发送控制指令
                setBusServoMove(servo_id, pulse, self.move_duration)
                
                rospy.logdebug(f"Servo {servo_id} 插值设置: {pulse} ({current_angle:.1f}°)")

            except Exception as e:
                rospy.logerr(f"关节 {joint_name} 控制异常: {str(e)}")

    def run(self):
        rospy.spin()

if __name__ == '__main__':
    node = JointStateToServoNode()
    node.run()