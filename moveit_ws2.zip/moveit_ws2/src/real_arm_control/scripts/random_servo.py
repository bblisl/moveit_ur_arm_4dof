#!/usr/bin/env python3
import rospy
from std_msgs.msg import Float32MultiArray
import time
import random
import pandas as pd
import matplotlib.pyplot as plt
from ServoControl import *

class EnhancedServoController:
    def __init__(self):
        rospy.init_node('enhanced_servo_controller')
        
        # 初始化发布器
        self.target_pub = rospy.Publisher('/servo_target_angles', Float32MultiArray, queue_size=10)
        self.actual_pub = rospy.Publisher('/servo_actual_angles', Float32MultiArray, queue_size=10)
        
        # 数据存储结构
        self.target_records = []
        self.actual_records = []
        
        # 运动参数
        self.angle_ratio = 1000 / 240
        self.servo_ranges = {
            1: (60.0, 170.0),   # Gripper
            2: (60.0, 180.0),   # Wrist
            3: (98.0, 218.0),   # Elbow
            4: (70.0, 170.0)    # Rotary Base
        }
        self.servo_names = {
            1: 'Gripper',
            2: 'Wrist',
            3: 'Elbow',
            4: 'Rotary Base'
        }

    def angle_to_pulse(self, angle):
        return int(angle * self.angle_ratio)

    def _publish_with_timestamp(self, pub, angles):
        """带时间戳的角度发布"""
        msg = Float32MultiArray()
        msg.data = [time.time()]
        for sid in sorted(angles):
            msg.data.extend([sid, angles[sid]])
        pub.publish(msg)
        return msg.data[0]

    def move_and_record(self, servo_cmds, duration):
        """运动记录核心方法"""
        try:
            if len(servo_cmds) == 1:
                sid, angle = list(servo_cmds.items())[0]
                setBusServoMove(sid, self.angle_to_pulse(angle), duration)
            else:
                servos = []
                for sid, angle in servo_cmds.items():
                    servos.extend([sid, self.angle_to_pulse(angle)])
                setMoreBusServoMove(servos, len(servo_cmds), duration)
            
            target_ts = self._publish_with_timestamp(self.target_pub, servo_cmds)
            self.target_records.append((target_ts, servo_cmds))
            
            # 调整等待时间
            sleep_time = duration/1000 + 0.7
            time.sleep(sleep_time)
            
            getServosPosition(list(servo_cmds.keys()))
            time.sleep(0.02)
            result = readSerialData()
            
            if result and result[0] == LOBOT_CMD_MULT_SERVO_POS_READ:
                actual_ts = time.time()  # 使用实际读取时间
                actual_angles = self._parse_positions(result[1], servo_cmds.keys())
                self._publish_with_timestamp(self.actual_pub, actual_angles)
                self.actual_records.append((actual_ts, actual_angles))
                
        except Exception as e:
            rospy.logerr(f"Movement error: {str(e)}")

    def _parse_positions(self, data, expected_ids):
        pos_dict = {}
        num = data[0]
        ptr = 1
        for _ in range(num):
            sid = data[ptr]
            pulse = (data[ptr+2] << 8) | data[ptr+1]
            pos_dict[sid] = round(pulse / self.angle_ratio, 1)
            ptr += 3
        return pos_dict

    def execute(self):
        """执行3分钟随机运动"""
        start_time = time.time()
        end_time = start_time + 180  # 3分钟
        
        while time.time() < end_time and not rospy.is_shutdown():
            # 随机选择1-4个舵机
            num_servos = random.randint(1, 4)
            selected_servos = random.sample([1,2,3,4], num_servos)
            
            # 生成随机角度
            servo_cmds = {}
            for sid in selected_servos:
                min_a, max_a = self.servo_ranges[sid]
                angle = round(random.uniform(min_a, max_a), 1)
                servo_cmds[sid] = angle
            
            # 随机持续时间(0.5-3秒)
            duration = random.randint(500, 3000)
            
            self.move_and_record(servo_cmds, duration)
            
            # 剩余时间显示
            remaining = end_time - time.time()
            rospy.loginfo(f"Remaining: {remaining:.1f}s | Moving: {servo_cmds}")

    def generate_reports(self):
        """生成增强版报表（修正版）"""
        # 创建数据框
        target_df = pd.DataFrame([
            {'Timestamp': ts, 'ServoID': sid, 'TargetAngle': angle}
            for ts, cmds in self.target_records
            for sid, angle in cmds.items()
        ])
        
        actual_df = pd.DataFrame([
            {'Timestamp': ts, 'ServoID': sid, 'ActualAngle': angle}
            for ts, cmds in self.actual_records
            for sid, angle in cmds.items()
        ])

        # 合并数据时精确对齐时间戳
        merged_df = pd.merge_asof(
            actual_df.sort_values('Timestamp'),
            target_df.sort_values('Timestamp'),
            on='Timestamp',
            by='ServoID',
            suffixes=('_actual', '_target'),
            tolerance=0.1  # 允许0.1秒时间差
        ).dropna()  # 移除未匹配的数据

        # 统一计算相对时间
        start_time = merged_df['Timestamp'].min()
        merged_df['RelativeTime'] = merged_df['Timestamp'] - start_time
        
        # 计算误差
        merged_df['Error'] = abs(merged_df['ActualAngle'] - merged_df['TargetAngle'])
        
        # 生成统计
        stats = merged_df.groupby('ServoID')['Error'].agg(['mean', 'std']).reset_index()
        stats.columns = ['ServoID', 'AverageError', 'StdDev']

        # 创建可视化图表
        plt.figure(figsize=(18, 12))
        for idx, sid in enumerate([1,2,3,4], 1):
            plt.subplot(2,2,idx)
            servo_data = merged_df[merged_df['ServoID'] == sid]
            
            # 绘制带标记的数据点
            plt.plot(servo_data['RelativeTime'], servo_data['TargetAngle'], 
                    'b-o', markersize=5, linewidth=1, label='Target')
            plt.plot(servo_data['RelativeTime'], servo_data['ActualAngle'],
                    'r--s', markersize=4, alpha=0.7, linewidth=1, label='Actual')
            
            # 添加统计信息
            stats_text = (f"Avg Error: {stats[stats['ServoID']==sid]['AverageError'].values[0]:.2f}°\n"
                        f"Std Dev: {stats[stats['ServoID']==sid]['StdDev'].values[0]:.2f}")
            plt.annotate(stats_text, xy=(0.05, 0.75), xycoords='axes fraction',
                        bbox=dict(boxstyle="round", fc="white", ec="gray", pad=0.3))
            
            plt.title(f'{self.servo_names[sid]} Performance (3 Minutes)')
            plt.xlabel('Time (seconds)')
            plt.ylabel('Angle (degrees)')
            plt.legend()
            plt.grid(True)
        
        plt.tight_layout()
        plt.savefig('enhanced_performance_report.png', dpi=300)
        plt.show()

        # 保存数据
        merged_df.to_csv('full_servo_data.csv', index=False)
        stats.to_csv('error_statistics.csv', index=False)

if __name__ == '__main__':
    try:
        controller = EnhancedServoController()
        controller.execute()
        controller.generate_reports()
        rospy.loginfo("Enhanced report generation completed")
    except rospy.ROSInterruptException:
        pass