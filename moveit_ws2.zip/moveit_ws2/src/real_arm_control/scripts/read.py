#!/usr/bin/env python3
import rospy
import random
import signal
from std_msgs.msg import Float32MultiArray
import time
import pandas as pd
import matplotlib.pyplot as plt
from ServoControl import *

class EnhancedServoController:
    def __init__(self):
        rospy.init_node('enhanced_servo_controller')
        
        # 初始化发布器
        self.target_pub = rospy.Publisher('/servo_target_angles', Float32MultiArray, queue_size=10)
        self.actual_pub = rospy.Publisher('/servo_actual_angles', Float32MultiArray, queue_size=10)
        
        # 数据存储结构
        self.target_records = []
        self.actual_records = []
        
        # 运动参数
        self.angle_ratio = 1000 / 240  # 角度-脉冲转换系数
        self.servo_ranges = {           
            1: (60.0, 170.0),  # Gripper
            2: (60.0, 180.0),  # Wrist
            3: (98.0, 218.0),  # Elbow
            4: (70.0, 170.0)   # Rotary Base
        }
        self.max_angle_delta = 50.0     # 单次运动最大角度变化量
        self.target_total_duration = 180  # 总运动时长约3分钟（秒）
        self.total_duration = 0           
        self.running = True               
        self.current_angles = {          # 当前角度（初始为范围中间值）
            sid: round((min_angle + max_angle)/2, 1) 
            for sid, (min_angle, max_angle) in self.servo_ranges.items()
        }
        
        # 注册Ctrl+C中断处理
        signal.signal(signal.SIGINT, self.handle_interrupt)

    def handle_interrupt(self, signum, frame):
        self.running = False
        rospy.loginfo("\n检测到用户中断，正在保存当前数据...")

    def angle_to_pulse(self, angle):
        return int(angle * self.angle_ratio)

    def _publish_with_timestamp(self, pub, angles):
        msg = Float32MultiArray()
        msg.data = [time.time()]  # 时间戳作为第一个数据
        for sid in sorted(angles):
            msg.data.extend([sid, angles[sid]])
        pub.publish(msg)
        return msg.data[0]

    def move_and_record(self, servo_cmds, duration):
        """核心逻辑：发送信号后等待1秒再读取角度"""
        # 发送控制信号
        if len(servo_cmds) == 1:
            sid, angle = list(servo_cmds.items())[0]
            setBusServoMove(sid, self.angle_to_pulse(angle), duration)
        else:
            servos = []
            for sid, angle in servo_cmds.items():
                servos.extend([sid, self.angle_to_pulse(angle)])
            setMoreBusServoMove(servos, len(servo_cmds), duration)
        
        # 记录目标角度（原始时间戳）
        target_ts = self._publish_with_timestamp(self.target_pub, servo_cmds)
        self.target_records.append((target_ts, servo_cmds))
        
        # 关键修改：发送信号后先等待运动时间，再额外等待1秒（总延迟=duration/1000 + 1）
        time.sleep(duration/1000)          # 等待舵机运动完成
        time.sleep(1)                      # 额外等待1秒后读取角度（满足"发送信号后隔1s再读取"）
        
        # 读取实际角度
        getServosPosition(list(servo_cmds.keys()))
        time.sleep(0.02)  # 等待串口数据稳定
        result = readSerialData()
        
        if result and result[0] == LOBOT_CMD_MULT_SERVO_POS_READ:
            # 实际时间戳 = 目标时间戳 + 运动时间（duration/1000） （提前1秒）
            actual_ts = target_ts + duration/1000  
            actual_angles = self._parse_positions(result[1], servo_cmds.keys())
            self._publish_with_timestamp(self.actual_pub, actual_angles)
            self.actual_records.append((actual_ts, actual_angles))
            
            # 更新当前角度（以实际角度为准）
            for sid, angle in actual_angles.items():
                self.current_angles[sid] = angle

    def _parse_positions(self, data, expected_ids):
        pos_dict = {}
        num = data[0]
        ptr = 1
        for _ in range(num):
            sid = data[ptr]
            pulse = (data[ptr+2] << 8) | data[ptr+1]
            pos_dict[sid] = round(pulse / self.angle_ratio, 1)
            ptr += 3
        return pos_dict

    def generate_random_command(self):
        num_servos = random.randint(1, 4)
        selected_servos = random.sample([1,2,3,4], num_servos)
        
        cmd = {}
        for sid in selected_servos:
            current_angle = self.current_angles[sid]
            min_angle, max_angle = self.servo_ranges[sid]
            
            delta_min = max(min_angle - current_angle, -self.max_angle_delta)
            delta_max = min(max_angle - current_angle, self.max_angle_delta)
            delta = random.uniform(delta_min, delta_max)
            
            target_angle = round(current_angle + delta, 1)
            cmd[sid] = target_angle
        
        duration = random.randint(500, 1000)
        return cmd, duration

    def execute(self):
        rospy.loginfo("开始随机运动实验（总时长约3分钟，Ctrl+C可中断）")
        while self.running and self.total_duration < self.target_total_duration:
            servo_cmds, duration = self.generate_random_command()
            
            rospy.loginfo(f"执行指令：{servo_cmds} | 时长：{duration}ms")
            self.move_and_record(servo_cmds, duration)
            
            # 累计时长 = 运动时间 + 1秒延迟（与实际等待逻辑一致）
            self.total_duration += (duration/1000) + 1  
            rospy.loginfo(f"已运行：{self.total_duration:.1f}s | 剩余：{self.target_total_duration - self.total_duration:.1f}s")

    def generate_reports(self):
        if not self.target_records or not self.actual_records:
            rospy.loginfo("无有效数据，跳过报告生成")
            return

        # 整理数据（实际时间戳已提前1秒）
        target_df = pd.DataFrame([
            {'Timestamp': ts, 'ServoID': sid, 'TargetAngle': angle}
            for ts, cmds in self.target_records
            for sid, angle in cmds.items()
        ])
        actual_df = pd.DataFrame([
            {'Timestamp': ts, 'ServoID': sid, 'ActualAngle': angle}
            for ts, cmds in self.actual_records
            for sid, angle in cmds.items()
        ])

        # 按时间戳合并（实际时间戳已提前，直接对齐）
        merged_df = pd.merge_asof(
            actual_df.sort_values('Timestamp'),
            target_df.sort_values('Timestamp'),
            on='Timestamp',
            by='ServoID',
            suffixes=('_actual', '_target')
        )
        merged_df['Error'] = merged_df['ActualAngle'] - merged_df['TargetAngle']
        stats = merged_df.groupby('ServoID')['Error'].agg(['mean', 'std']).reset_index()
        stats.columns = ['ServoID', 'AverageError', 'StdDev']

        # 保存数据
        target_df.to_csv('target_angles.csv', index=False)
        actual_df.to_csv('actual_angles.csv', index=False)
        stats.to_csv('error_statistics.csv', index=False)

        # 绘制对比图（实际时间戳提前1秒）
        plt.figure(figsize=(16, 10))
        servo_names = {1: 'Gripper', 2: 'Wrist', 3: 'Elbow', 4: 'Rotary Base'}
        
        for idx, sid in enumerate([1,2,3,4], 1):
            plt.subplot(2, 2, idx)
            servo_data = merged_df[merged_df['ServoID'] == sid]
            stats_data = stats[stats['ServoID'] == sid]

            # 目标角度时间轴（原始时间）
            plt.plot(servo_data['Timestamp'], servo_data['TargetAngle'], 
                     'b-', linewidth=1, label='Target (Original Time)')
            plt.scatter(servo_data['Timestamp'], servo_data['TargetAngle'], 
                        color='blue', marker='o', s=15, label='Target Points')

            # 实际角度时间轴（提前1秒）
            plt.plot(servo_data['Timestamp'], servo_data['ActualAngle'], 
                     'r--', linewidth=1, alpha=0.7, label='Actual (Time Advanced by 1s)')
            plt.scatter(servo_data['Timestamp'], servo_data['ActualAngle'], 
                        color='red', marker='x', s=20, label='Actual Points')

            # 统计标注
            stats_text = (f"Avg Error: {stats_data['AverageError'].values[0]:.2f}°\n"
                          f"Std Dev: {stats_data['StdDev'].values[0]:.2f}°")
            plt.annotate(stats_text, xy=(0.05, 0.8), xycoords='axes fraction',
                        bbox=dict(boxstyle="round", fc="white", ec="gray", pad=0.3))

            plt.title(f'{servo_names[sid]} (Servo {sid}) Performance')
            plt.xlabel('Timestamp (s) [Actual Time Advanced by 1s]')
            plt.ylabel('Angle (°)')
            plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.grid(linestyle='--', alpha=0.6)

        plt.tight_layout()
        plt.savefig('servo_performance_report.png', dpi=300, bbox_inches='tight')
        plt.show()
        rospy.loginfo("报告生成完成，已保存至当前目录")

if __name__ == '__main__':
    try:
        controller = EnhancedServoController()
        controller.execute()
        controller.generate_reports()
        rospy.loginfo("实验结束")
    except Exception as e:
        rospy.logerr(f"程序异常终止：{str(e)}")