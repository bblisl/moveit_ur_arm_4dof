#!/usr/bin/env python3
import rospy
from std_msgs.msg import Float32MultiArray
import time
import pandas as pd
import matplotlib.pyplot as plt
from ServoControl import *

class EnhancedServoController:
    def __init__(self):
        rospy.init_node('enhanced_servo_controller')
        
        # 初始化发布器
        self.target_pub = rospy.Publisher('/servo_target_angles', Float32MultiArray, queue_size=10)
        self.actual_pub = rospy.Publisher('/servo_actual_angles', Float32MultiArray, queue_size=10)
        
        # 数据存储结构
        self.target_records = []
        self.actual_records = []
        
        # 运动参数
        self.angle_ratio = 1000 / 240
        self.total_cycles = 10  # 循环次数

    def angle_to_pulse(self, angle):
        return int(angle * self.angle_ratio)

    def _publish_with_timestamp(self, pub, angles):
        """带时间戳的角度发布"""
        msg = Float32MultiArray()
        msg.data = [time.time()]
        for sid in sorted(angles):
            msg.data.extend([sid, angles[sid]])
        pub.publish(msg)
        return msg.data[0]

    def move_and_record(self, servo_cmds, duration):
        """运动记录核心方法"""
        if len(servo_cmds) == 1:
            sid, angle = list(servo_cmds.items())[0]
            setBusServoMove(sid, self.angle_to_pulse(angle), duration)
        else:
            servos = []
            for sid, angle in servo_cmds.items():
                servos.extend([sid, self.angle_to_pulse(angle)])
            setMoreBusServoMove(servos, len(servo_cmds), duration)
        
        target_ts = self._publish_with_timestamp(self.target_pub, servo_cmds)
        self.target_records.append((target_ts, servo_cmds))
        
        time.sleep(duration/1000 + 0.5)
        
        getServosPosition(list(servo_cmds.keys()))
        time.sleep(0.02)
        result = readSerialData()
        
        if result and result[0] == LOBOT_CMD_MULT_SERVO_POS_READ:
            actual_ts = target_ts + 0.5
            actual_angles = self._parse_positions(result[1], servo_cmds.keys())
            self._publish_with_timestamp(self.actual_pub, actual_angles)
            self.actual_records.append((actual_ts, actual_angles))

    def _parse_positions(self, data, expected_ids):
        pos_dict = {}
        num = data[0]
        ptr = 1
        for _ in range(num):
            sid = data[ptr]
            pulse = (data[ptr+2] << 8) | data[ptr+1]
            pos_dict[sid] = round(pulse / self.angle_ratio, 1)
            ptr += 3
        return pos_dict

    # === 运动阶段方法 ===
    def initial_stage(self):
        self.move_and_record({1: 64.8}, 2000)
        self.move_and_record({1: 130.0}, 2000)
        self.move_and_record({2: 90.0}, 2000)
        self.move_and_record({3: 103.2}, 3000)
        self.move_and_record({3: 115.2}, 500)
        self.move_and_record({4: 150.0}, 2000)

    def fast_stage(self):
        self.move_and_record({1: 69.6}, 2000)
        self.move_and_record({2: 120.0}, 500)
        self.move_and_record({3: 103.2}, 500)
        self.move_and_record({4: 60.0}, 2000)

    def reset_stage(self):
        self.move_and_record({1: 145.2, 4: 120.0}, 2000)
        self.move_and_record({2: 120.0, 3: 217.2}, 3000)

    def execute_cycle(self):
        """执行单次完整运动周期"""
        self.initial_stage()
        self.fast_stage()
        self.reset_stage()
        time.sleep(1)  # 周期间隔

    def execute(self):
        """执行10次循环运动"""
        for cycle in range(self.total_cycles):
            rospy.loginfo(f"Starting cycle {cycle+1}/{self.total_cycles}")
            self.execute_cycle()

    def generate_reports(self):
        """生成增强版报表"""
        # 创建独立表格
        target_df = pd.DataFrame([
            {'Cycle': i//6+1, 'Timestamp': ts, 'ServoID': sid, 'TargetAngle': angle}
            for i, (ts, cmds) in enumerate(self.target_records)
            for sid, angle in cmds.items()
        ])
        
        actual_df = pd.DataFrame([
            {'Cycle': i//6+1, 'Timestamp': ts, 'ServoID': sid, 'ActualAngle': angle}
            for i, (ts, cmds) in enumerate(self.actual_records)
            for sid, angle in cmds.items()
        ])

        # 保存原始表格
        target_df.to_csv('target_angles_table.csv', index=False)
        actual_df.to_csv('actual_angles_table.csv', index=False)

        # 计算统计指标
        merged_df = pd.merge_asof(
            actual_df.sort_values('Timestamp'),
            target_df.sort_values('Timestamp'),
            on='Timestamp',
            by='ServoID',
            suffixes=('_actual', '_target')
        )
        merged_df['Error'] = abs(merged_df['ActualAngle'] - merged_df['TargetAngle'])
        stats = merged_df.groupby('ServoID')['Error'].agg(['mean', 'std']).reset_index()
        stats.columns = ['ServoID', 'AverageError', 'StdDev']

        # 生成带统计的图表
        plt.figure(figsize=(18, 12))
        for idx, sid in enumerate([1,2,3,4], 1):
            plt.subplot(2,2,idx)
            servo_data = merged_df[merged_df['ServoID'] == sid]
            stats_data = stats[stats['ServoID'] == sid]
            
            plt.plot(servo_data['Timestamp'], servo_data['TargetAngle'], 'b-', label='Target')
            plt.plot(servo_data['Timestamp'], servo_data['ActualAngle'], 'r--', alpha=0.6, label='Actual')
            
            # 添加统计信息
            stats_text = f"Avg Error: {stats_data['AverageError'].values[0]:.2f}°\nStd Dev: {stats_data['StdDev'].values[0]:.2f}"
            plt.annotate(stats_text, xy=(0.05, 0.75), xycoords='axes fraction',
                        bbox=dict(boxstyle="round", fc="white", ec="gray", pad=0.3))
            
            plt.title(f'Servo {sid} Performance (10 Cycles)')
            plt.xlabel('Timestamp')
            plt.ylabel('Angle (deg)')
            plt.legend()
            plt.grid(True)
        
        plt.tight_layout()
        plt.savefig('enhanced_performance_report.png', dpi=300)
        plt.show()

        # 保存统计表格
        stats.to_csv('error_statistics.csv', index=False)

if __name__ == '__main__':
    try:
        controller = EnhancedServoController()
        controller.execute()
        controller.generate_reports()
        rospy.loginfo("Enhanced report generation completed")
    except rospy.ROSInterruptException:
        pass