#!/usr/bin/env python3
import rospy
import numpy as np
import csv
import os
from datetime import datetime
from sensor_msgs.msg import JointState
import ServoControl

class ServoFeedback:
    def __init__(self):
        rospy.init_node('servo_feedback')
        
        # 设置存储路径
        self.save_dir = os.path.expanduser("~/moveit_ws2")
        os.makedirs(self.save_dir, exist_ok=True)
        filename = f"joint_states_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        self.file_path = os.path.join(self.save_dir, filename)
        
        # CSV文件初始化
        self.csv_file = open(self.file_path, 'w')
        self.csv_writer = csv.writer(self.csv_file)
        self.csv_writer.writerow(['timestamp', 'joint1', 'joint2', 'joint3', 'joint4_left', 'joint4_right'])
        rospy.loginfo(f"数据将保存至：{self.file_path}")

        # 硬件参数配置
        self.update_rate = 20  # Hz
        self.servo_ids = [1, 2, 3, 4]
        
        # 转换参数（保持原有配置）
        self.joint_conversion = {
            4: {'offset': 120.0, 'ratio': 1.0},
            3: {'offset': 217.2, 'ratio': -1.0},
            2: {'offset': 120.0, 'ratio': -1.0},
            1: {'range': {'deg': [67.0, 160.0], 'rad': [0.024, 0.0]}}
        }

        # ROS组件初始化
        self.pub = rospy.Publisher('/joint_states', JointState, queue_size=1)
        self.timer = rospy.Timer(rospy.Duration(1/self.update_rate), self.update)
        rospy.on_shutdown(self.cleanup)
        rospy.loginfo("舵机反馈节点已启动")

    def servo_to_joint(self, servo_id, pulse):
        """舵机脉冲转关节弧度"""
        if servo_id == 1:
            deg = pulse * 240 / 1000
            return np.interp(deg, 
                self.joint_conversion[1]['range']['deg'],
                self.joint_conversion[1]['range']['rad']
            )
        else:
            cfg = self.joint_conversion[servo_id]
            return np.radians((pulse * 0.24 - cfg['offset']) / cfg['ratio'])

    def update(self, event):
        """数据更新回调"""
        try:
            # 硬件数据读取
            ServoControl.getServosPosition(self.servo_ids)
            data = ServoControl.readSerialData()
            
            if data and data[0] == 0x15:  # 校验数据头
                positions = []
                raw_data = data[1]
                servo_count = raw_data[0]
                
                # 数据解析
                for i in range(servo_count):
                    sid = raw_data[1 + i*3]
                    pos_low = raw_data[2 + i*3]
                    pos_high = raw_data[3 + i*3]
                    positions.append( (sid, (pos_high << 8) | pos_low) )
                
                # 构建消息
                msg = JointState()
                msg.header.stamp = rospy.Time.now()
                msg.name = ['joint1', 'joint2', 'joint3', 'joint4_left', 'joint4_right']
                
                # 数据转换
                pos_dict = {sid: pos for sid, pos in positions}
                msg.position = [
                    self.servo_to_joint(4, pos_dict.get(4, 500)),
                    self.servo_to_joint(3, pos_dict.get(3, 500)),
                    self.servo_to_joint(2, pos_dict.get(2, 500)),
                    self.servo_to_joint(1, pos_dict.get(1, 500)),
                    self.servo_to_joint(1, pos_dict.get(1, 500))  # 双爪同步
                ]
                
                # 发布并存储
                self.pub.publish(msg)
                self._save_to_csv(msg)
                rospy.logdebug(f"已写入：{msg.position}")

        except Exception as e:
            rospy.logerr(f"数据处理异常：{str(e)}")
            if "serial" in str(e).lower():
                rospy.logwarn("建议检查：1. 串口连接 2. 舵机ID配置")

    def _save_to_csv(self, msg):
        """安全存储数据"""
        try:
            timestamp = msg.header.stamp.to_sec()
            positions = [round(p, 6) for p in msg.position]  # 保留6位小数
            self.csv_writer.writerow([timestamp] + positions)
            self.csv_file.flush()
        except IOError as e:
            rospy.logerr(f"文件写入失败：{str(e)}\n请检查：1. 磁盘空间 2. 文件权限")

    def cleanup(self):
        """资源清理"""
        self.csv_file.close()
        rospy.loginfo(f"已保存{os.path.getsize(self.file_path)}字节数据到：{self.file_path}")
        if os.path.getsize(self.file_path) == 0:
            rospy.logwarn("警告：生成的CSV文件为空，请检查数据流")

if __name__ == '__main__':
    try:
        node = ServoFeedback()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
    except PermissionError:
        rospy.logfatal("权限被拒绝！请尝试：\n"
                       "sudo chmod a+rw ~/moveit_ws2")